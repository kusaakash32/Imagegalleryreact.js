export const Images = [
    {
        original: 'https://picsum.photos/id/1000/800/500/',
        thumbnail: 'https://picsum.photos/id/1000/100/100'
    },
    {
        original: 'https://picsum.photos/id/10/800/500/',
        thumbnail: 'https://picsum.photos/id/10/100/100'
    },
    {
        original: 'https://picsum.photos/id/12/800/500/',
        thumbnail: 'https://picsum.photos/id/12/100/100'
    },
    {
        original: 'https://picsum.photos/id/1018/800/500/',
        thumbnail: 'https://picsum.photos/id/1018/100/100'
    },
    {
        original: 'https://picsum.photos/id/1012/800/500/',
        thumbnail: 'https://picsum.photos/id/1012/100/100'
    }
]
   