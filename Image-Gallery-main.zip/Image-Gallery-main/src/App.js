import logo from './logo.svg';
import './App.css';
import PhotoGallery from './Components/Imggallery';


function App() {
  return (
    <div className="App">
      <PhotoGallery />
    </div>
  );
}

export default App;
